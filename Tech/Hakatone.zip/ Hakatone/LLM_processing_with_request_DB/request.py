import requests

url = "http://localhost:3000/api/get_db"

data = {
    "userId": 6
}

response = requests.get(url, json=data)

if response.status_code == 200:

    json_response = response.json()
 
    if 's7survey' in json_response:
        for board in json_response['s7survey']:
            comments = board.get('comments', 'Комментарии не найдены')
            print(f"Комментарии для доски {board['id']}: {comments}")
    else:
        print("Нет досок в ответе.")
else:
    print(f"Ошибка запроса: {response.status_code}, {response.text}")
