const express = require('express');
const mysql = require('mysql2/promise');

const app = express();
const router = express.Router();

app.use(express.json()); // Middleware для парсинга JSON

// Создание пула соединений MySQL
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'password',
    database: 's7survey',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    port: 3306
});

// Проверка подключения
async function checkConnection() {
    try {
        const connection = await pool.getConnection();
        console.log('Подключено к MySQL');
        connection.release();
    } catch (err) {
        console.error('Ошибка подключения к MySQL:', err);
    }
}
checkConnection();

router.get('/get_db', async (req, res) => {
    const userId = req.body.userId; // Получаем userId из тела запроса
    if (!userId) {
        return res.status(400).json({ error: 'Не указан userId' });
    }

    try {
        const [results] = await pool.query('SELECT * FROM s7survey WHERE id = ?', [userId]);
        res.json({ s7survey: results });
    } catch (err) {
        console.error('Ошибка запроса:', err);
        res.status(500).json({ error: 'Ошибка сервера' });
    }
});

app.use('/api', router);

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Сервер запущен на http://localhost:${PORT}`);
});
